export class Rol {


  idRol: number=0 ;
  nombreRol: string;
  descripcion: string;

}
