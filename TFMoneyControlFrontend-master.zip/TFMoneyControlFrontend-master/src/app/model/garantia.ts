
import {Usuario} from './usuario';

export class Garantia {
  idGarantia: number=0;
  tipoGarantia: string;
  descripcion: string;
  valorGarantia: number;
  usuario: Usuario;
}
