
export class Estadisticasprestamo {

  promedioMonto:number;
  totalMonto:number;
  cantidadPrestamos:number;

}
