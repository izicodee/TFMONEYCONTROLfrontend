export class RequestDto {
  email : string;
  contrasena: string;

}
