
export class PrestamoCorrespondiente {

  PrestamoId:       number=0;
  montoPrestamo:     number;
  tasaInteres:     number;
  montoTotalaPagar:    number;
  FechaMaximaDePago: Date;
}
