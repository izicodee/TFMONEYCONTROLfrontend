
export class Prestamoperiodo {

  idUsuario: number=0;
  nombreUsuario: String;
  idPrestamo: number;
  montoPrestamo: number;
  fechaInicioPrestamo: Date;
  fechaFinPrestamo: Date;
  estadoPrestamo: String;

}
