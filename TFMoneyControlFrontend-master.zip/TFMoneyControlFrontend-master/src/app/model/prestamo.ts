import {Usuario} from './usuario';

export class Prestamo {

  idPrestamo: number=0;
  monto: number;
  tasaInteres: number;
  fechaInicio: Date;
  fechaFin: Date;
  estado : string;
  usuario: Usuario;




}
