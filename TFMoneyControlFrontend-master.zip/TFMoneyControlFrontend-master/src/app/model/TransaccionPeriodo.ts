export class TransaccionPeriodo {


  idUsuario: number=0;
  nombreUsuario: string;
  idTransaccion: number;
  montoTransaccion: number;
  fechaTransaccion: Date;
  estadoTransaccion: string;


}
