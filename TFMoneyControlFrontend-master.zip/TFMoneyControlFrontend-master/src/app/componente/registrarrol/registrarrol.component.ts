import { Component } from '@angular/core';

@Component({
  selector: 'app-registrarrol',
  standalone: true,
  imports: [],
  templateUrl: './registrarrol.component.html',
  styleUrl: './registrarrol.component.css'
})
export class RegistrarrolComponent {


}
